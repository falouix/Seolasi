$(document).ready(function(){
    $('.flx-form').hover(function(){
            $('.flx-input').removeClass('input_hover');
    });

    $('.flx-form').mouseover(function(){
        $('.flx-input').addClass('input_hover');
    });
    
    $('.flx-input').focus(function(){
        $('.flx-input').addClass('input_hover_important');

    });

});